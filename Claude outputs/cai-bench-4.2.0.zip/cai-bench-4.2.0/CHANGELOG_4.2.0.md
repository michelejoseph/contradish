## 4.2.0

- New `temporal` split (`data/temporal.jsonl`, 48 scenarios, 336 prompts) and `caibench_temporal.py`.
  - One authorized amendment with an effective date is applied to events on either side of that date, under a non-retroactive and an explicitly retroactive scope.
  - Metrics: Temporal and Scope Sensitivity Indexes and pair profiles (discriminating, retroactive, stale, inverted).
  - Gold labels were cross-checked against contradish `derive_transition` with effective dates: 240 labels, 0 disagreements.
- New `provider` split (`data/provider.jsonl`, 48 scenarios, 240 prompts) and `caibench_provider.py`.
  - The same amendment is delivered as a mid-conversation system message, a user message, or a native tool result.
  - Scored against Anthropic's published precedence rules (read 2026-10-14) with the Provider Conformance Index.
  - Native-role adapters for Anthropic, OpenAI and Ollama.
  - Gold labels were cross-checked against contradish: 192 labels, 0 disagreements.
- `run_local.py`: resumable, standard-library runner for local Ollama models across the authority, temporal, provider and dynamics L1 splits.
- `audit/`: 200-item stratified human audit sheets with gold labels hidden, an annotator guide, and `audit_agreement.py`.
- Includes 4.1.0 (`authority` split), which was not released separately.
- Data in existing splits unchanged; `data/dynamics.jsonl` is identical to 4.0.0.
