#!/usr/bin/env python3
"""Run CAI-Bench splits against local Ollama models. Standard library only; resumable.

  python3 run_local.py                       # default models and splits
  python3 run_local.py --models qwen2.5:7b   # one model
  python3 run_local.py --splits authority,temporal

Writes results/<model>/<split>.jsonl in the format each split's `score` command reads,
and results/progress.json (counts, speed, ETA). Re-running skips finished items.
"""
import argparse
import json
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import caibench_dynamics as D  # noqa: E402
import caibench_authority as A  # noqa: E402
import caibench_temporal as T  # noqa: E402
import caibench_provider as P  # noqa: E402

OLLAMA = "http://localhost:11434"
DEFAULT_MODELS = ["qwen2.5:7b", "qwen2.5:3b", "llama3.2:3b", "llama3.1:8b"]
SPLITS = ["authority", "temporal", "provider", "dynamics"]
OPTIONS = {"temperature": 0, "seed": 0, "num_predict": 512, "num_ctx": 8192}


def chat(model, messages, tools=None):
    body = {"model": model, "messages": messages, "stream": False, "options": OPTIONS}
    if tools:
        body["tools"] = tools
    req = urllib.request.Request(OLLAMA + "/api/chat", data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=900) as r:
                return json.loads(r.read())["message"].get("content", "") or ""
        except Exception as e:  # noqa: BLE001
            if attempt == 4:
                raise
            print(f"  retry after error: {e}", flush=True)
            time.sleep(5 * (attempt + 1))


def installed():
    with urllib.request.urlopen(OLLAMA + "/api/tags", timeout=30) as r:
        return {m["name"] for m in json.loads(r.read())["models"]}


def jobs(split):
    """(item_id, kind, payload) in run order; kind is 'single' or 'followup'."""
    if split == "authority":
        for r in D.load(HERE / "data" / "authority.jsonl"):
            yield r["item_id"], "single", {"messages": [{"role": "user", "content": A.prompt_of(r, A.item_order(r, True))}]}
    elif split == "temporal":
        for r in D.load(HERE / "data" / "temporal.jsonl"):
            yield r["item_id"], "single", {"messages": [{"role": "user", "content": T.prompt_of(r, T.item_order(r, True))}]}
    elif split == "provider":
        for r in D.load(HERE / "data" / "provider.jsonl"):
            tools = [{"type": "function", "function": t} for t in r["tools"]] or None
            yield r["item_id"], "single", {"messages": P.to_ollama(r["messages"]), "tools": tools}
    elif split == "dynamics":
        rows = [r for r in D.load(HERE / "data" / "dynamics.jsonl") if r["level"] == 1]
        rowmap = {r["item_id"]: r for r in rows}
        for r in sorted(rows, key=lambda r: r["variant_type"] != "base"):
            if r["followups"]:
                b = rowmap[r["base_item_id"]]
                yield r["item_id"], "followup", {"base_id": b["item_id"], "followups": r["followups"],
                                                 "base_prompt": D.prompt_of(b, D.item_order(b, True))}
            else:
                yield r["item_id"], "single", {"messages": [{"role": "user", "content": D.prompt_of(r, D.item_order(r, True))}]}


def run(model, split, progress):
    out = HERE / "results" / model.replace(":", "_").replace("/", "_") / f"{split}.jsonl"
    out.parent.mkdir(parents=True, exist_ok=True)
    done = {}
    if out.exists():
        for line in out.read_text().splitlines():
            if line.strip():
                d = json.loads(line); done[d["item_id"]] = d
    todo = [j for j in jobs(split) if j[0] not in done]
    key = f"{model}/{split}"
    progress[key] = {"done": len(done), "total": len(done) + len(todo), "started": time.time()}
    with open(out, "a") as f:
        for i, (iid, kind, p) in enumerate(todo):
            t0 = time.time()
            if kind == "single":
                replies = [chat(model, p["messages"], p.get("tools"))]
            else:
                msgs = [{"role": "user", "content": p["base_prompt"]},
                        {"role": "assistant", "content": done[p["base_id"]]["samples"][0][0]}]
                replies = []
                for fu in p["followups"]:
                    msgs.append({"role": "user", "content": fu})
                    rep = chat(model, msgs); replies.append(rep)
                    msgs.append({"role": "assistant", "content": rep})
            rec = {"item_id": iid, "samples": [replies], "model": model, "provider": "ollama",
                   "options": OPTIONS, "seconds": round(time.time() - t0, 2),
                   "time": time.strftime("%Y-%m-%dT%H:%M:%S")}
            done[iid] = rec
            f.write(json.dumps(rec) + "\n"); f.flush()
            pr = progress[key]; pr["done"] += 1
            el = time.time() - pr["started"]; rate = (i + 1) / el
            pr["per_item_s"] = round(1 / rate, 1); pr["eta_min"] = round((pr["total"] - pr["done"]) / rate / 60, 1)
            if (i + 1) % 5 == 0 or pr["done"] == pr["total"]:
                (HERE / "results" / "progress.json").write_text(json.dumps(progress, indent=1))
                print(f"  {key}: {pr['done']}/{pr['total']}  {pr['per_item_s']}s/item  eta {pr['eta_min']} min", flush=True)
    progress[key]["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    (HERE / "results" / "progress.json").write_text(json.dumps(progress, indent=1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default=",".join(DEFAULT_MODELS))
    ap.add_argument("--splits", default=",".join(SPLITS))
    a = ap.parse_args()
    have = installed()
    models = [m for m in a.models.split(",") if m]
    splits = [s for s in a.splits.split(",") if s]
    progress = {"models": models, "splits": splits, "skipped_not_installed": [m for m in models if m not in have]}
    (HERE / "results").mkdir(exist_ok=True)
    print(f"CAI-Bench local run: models {models}, splits {splits}")
    if progress["skipped_not_installed"]:
        print(f"  not installed, skipped: {progress['skipped_not_installed']}")
    # The three standing splits for every model first, then dynamics.
    order = [(m, s) for s in splits if s != "dynamics" for m in models if m in have] + \
            [(m, "dynamics") for m in models if m in have and "dynamics" in splits]
    for m, s in order:
        print(f"== {m} / {s}", flush=True)
        run(m, s, progress)
    progress["all_finished"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    (HERE / "results" / "progress.json").write_text(json.dumps(progress, indent=1))
    print("all done")


if __name__ == "__main__":
    main()
