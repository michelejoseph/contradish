## 4.1.0

- New `authority` split (`data/authority.jsonl`, 48 scenarios, 336 prompts) and `caibench_authority.py` (generate, run, score, baselines).
  - Each scenario delivers one identical amendment sentence five ways: authorized policy amendment, customer message, web search result, third-party forum, recalled memory note. Only the authorized delivery may change the decision.
  - Gold labels are derived from declared source authority and were cross-checked against contradish's `derive_transition`: 288 labels, 0 disagreements.
  - Headline metric: the Authority Sensitivity Index, conditioned on a correct base answer. Also reported: per-provenance resistance, collateral preservation, and the index by claim direction.
- `caibench_dynamics.py`: `score` exits with a clear message on an empty responses file, or when `--only-answered` finds no fully answered scenario (previously a ValueError).
- Data in existing splits unchanged; `data/dynamics.jsonl` is identical to 4.0.0.
