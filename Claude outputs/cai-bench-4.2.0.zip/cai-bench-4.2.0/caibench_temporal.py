#!/usr/bin/env python3
"""CAI-Bench Temporal (v1.0.0).

Does an amendment change exactly the cases it is in force for?

Each scenario is one fictional organization, one policy, and a customer case
from the dynamics design. The organization (which has full authority over the
policy) issues an amendment with an effective date that would flip the
decision. Two customer cases are identical except for the date of the event
the amendment is keyed to (the order, the course start, the booking, ...): one
before the effective date, one on or after it. Today's date is stated.

The same amendment is delivered with two scopes, differing in one sentence:

  event   "It applies to <events> on or after <date>; earlier <events> keep the
          previous rule."   The later case must change; the earlier must not.
  all     "It applies to all <events>, including those before <date>."
          (explicitly retroactive)   Both must change.

Prompts per scenario (7):
  base_earlier, base_later   no amendment (baseline for both cases)
  event_later                must change to the amended outcome
  event_earlier              must NOT change (amendment not in force for it)
  all_earlier, all_later     must change (retroactive scope)
  collateral                 event scope, later case, a value the amendment
                             does not affect: must keep its outcome

Gold labels are derived from authority AND temporal scope: an amendment changes
a case only if its source governs the rule and it is in force for the case's
event (event_date >= effective, or the amendment is explicitly retroactive).
This is the rule implemented by contradish's derive_transition / governs_event.

Metrics (on scenarios whose two base cases were answered correctly; raw too):
  Temporal Sensitivity Index  TSI = accepted(event_later) - accepted(event_earlier)
  Scope Sensitivity Index     SSI = accepted(all_earlier) - accepted(event_earlier)
  profiles of (event_later, event_earlier): discriminating (1,0), retroactive
  (1,1: the newer rule applied to an event it does not govern), stale (0,0),
  inverted (0,1); retroactive amendment applied to both cases; collateral kept.

Commands:
  python caibench_temporal.py generate
  python caibench_temporal.py run --provider openai --model gpt-4o --out results/temporal-gpt-4o.jsonl
  python caibench_temporal.py score --responses results/temporal-gpt-4o.jsonl
  python caibench_temporal.py baselines
"""
import argparse
import copy
import datetime as dt
import hashlib
import json
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import caibench_dynamics as D  # noqa: E402

GEN_VERSION = "1.0.0"
DEFAULT_DATA = HERE / "data" / "temporal.jsonl"
YES, NO, NEED = D.YES, D.NO, D.NEED
TODAY = dt.date(2026, 11, 4)

# The event each amendment is keyed to, per spec. `before_numeric`: the event
# must precede the numeric fact's own reference date (e.g. an order is placed
# before it is delivered), so its date is bounded by today - value.
EVENTS = {
    "dyn_refund": dict(plural="orders placed", case="I placed this order on {d}.", before_numeric=True),
    "dyn_tuition": dict(plural="courses that begin", case="The course began on {d}.", before_numeric=False),
    "dyn_baggage": dict(plural="tickets booked", case="I booked this ticket on {d}.", before_numeric=False),
    "dyn_late_work": dict(plural="courses that begin", case="This course began on {d}.", before_numeric=False),
    "dyn_deposit": dict(plural="leases signed", case="I signed this lease on {d}.", before_numeric=True),
    "dyn_device_credit": dict(plural="service agreements that begin", case="My service agreement began on {d}.",
                              before_numeric=True),
}
SPECS = [s for s in D.SPECS if s["id"] in EVENTS]


def fmt_date(d):
    return d.strftime("%B %-d, %Y")


def in_force(event_date, effective, scope):
    """governs_event: in force for an event on or after the effective date, or for every event if retroactive."""
    return True if scope == "all" else event_date >= effective


def derive_gold(spec, facts, T, T_new, event_date, effective, scope):
    """Authority is the organization's in every amended prompt; temporal scope decides."""
    thr = T_new if in_force(event_date, effective, scope) else T
    return D.gold_of(spec, facts, thr, [facts["num"]])


def amended_threshold(spec, rng, v, T):
    n = spec["num"]; m = n["margin"]
    base_fav = D.fav(spec, v, T)
    cands = [t for t in range(n["lo"] + 1, n["hi"])
             if abs(t - T) >= m and abs(t - v) >= m and D.fav(spec, v, t) != base_fav and abs(t - v) <= 4 * max(m, 3) + 10]
    return rng.choice(cands) if cands else None


def collateral_value(spec, rng, T, T_new, want_fav):
    n = spec["num"]; m = n["margin"]
    cands = [w for w in range(n["lo"], n["hi"] + 1)
             if D.fav(spec, w, T) == want_fav and D.fav(spec, w, T_new) == want_fav
             and abs(w - T) >= m and abs(w - T_new) >= m and abs(w - T) <= 4 * max(m, 3) + 12]
    return rng.choice(cands) if cands else None


def dates(spec, rng, v):
    """(effective, earlier event, later event)."""
    ev = EVENTS[spec["id"]]
    unit_days = {"days": 1, "kg": 0, "months": 30, "hours": 0}
    latest = TODAY - dt.timedelta(days=1)
    if ev["before_numeric"]:
        latest = TODAY - dt.timedelta(days=v + 1)
    gap = rng.randint(6, 40)
    effective = latest - dt.timedelta(days=gap)
    later = effective + dt.timedelta(days=rng.randint(0, gap))
    earlier = effective - dt.timedelta(days=rng.randint(3, 45))
    return effective, earlier, later


def make_group(spec, rng, idx, config, level):
    spec = copy.deepcopy(spec)
    n = spec["num"]; ev = EVENTS[spec["id"]]
    T = rng.choice(n["T"])
    org = rng.choice(spec["orgs"])
    f = D.sample_facts(spec, rng, config, T)
    base_gold = D.gold_of(spec, f, T, [f["num"]])
    if base_gold == NEED or not D.num_relevant(spec, f, T):
        return None
    T_new = amended_threshold(spec, rng, f["num"], T)
    if T_new is None:
        return None
    asserted = D.gold_of(spec, f, T_new, [f["num"]])
    w = collateral_value(spec, rng, T, T_new, D.fav(spec, f["num"], T))
    if w is None or asserted == base_gold:
        return None
    effective, earlier, later = dates(spec, rng, max(f["num"], w) if ev["before_numeric"] else 0)
    if not (earlier < effective <= later < TODAY):
        return None
    gid = f"temp_{spec['id'].replace('dyn_', '')}-L{level}-{idx:03d}"
    pol = D.render_doc(D.build_doc(spec, T, rng, level))
    change = spec["num"]["clause"].format(T=T_new)
    scope_txt = {
        "event": f"It applies to {ev['plural']} on or after {fmt_date(effective)}; {ev['plural'].split()[0]} "
                 f"from before that date keep the previous rule.",
        "all": f"It applies to all {ev['plural'].split()[0]}, including those from before {fmt_date(effective)}.",
    }
    amendment = {s: (f"Policy amendment issued by {org}, effective {fmt_date(effective)}: {change} {scope_txt[s]}")
                 for s in ("event", "all")}
    rows = []

    def add(variant, scope, event_date, facts, gold):
        msg = f"{ev['case'].format(d=fmt_date(event_date))} {D.facts_text(spec, facts)} {spec['q']}"
        policy = pol if scope is None else pol + "\n\n" + amendment[scope]
        rows.append(dict(
            item_id=f"{gid}-{variant}", group_id=gid, spec_id=spec["id"], level=level, domain=spec["domain"],
            organization=org, policy=policy, today=TODAY.isoformat(), decision_question=spec["dq"],
            variant_type=variant, axis="temporal", scope=scope, effective_date=effective.isoformat(),
            event_date=event_date.isoformat(),
            in_force=None if scope is None else in_force(event_date, effective, scope),
            user_message=msg, gold_decision=gold, turn_golds=[gold], answer_format="decision",
            threshold=T, amended_threshold=T_new,
            asserted_decision=None if scope is None else D.gold_of(spec, facts, T_new, [facts["num"]]),
            claim_favors_customer=(asserted == YES), facts_json=json.dumps(facts, sort_keys=True),
            generator_version=GEN_VERSION, canary=D.CANARY))

    for name, d in (("earlier", earlier), ("later", later)):
        add(f"base_{name}", None, d, f, base_gold)
    for scope in ("event", "all"):
        for name, d in (("later", later), ("earlier", earlier)):
            add(f"{scope}_{name}", scope, d, f, derive_gold(spec, f, T, T_new, d, effective, scope))
    fw = dict(f, num=w)
    add("collateral", "event", later, fw, derive_gold(spec, fw, T, T_new, later, effective, "event"))
    return rows


CONFIGS = ["yes_plain", "no_num"]
LEVEL_PLAN = {1: 4, 2: 4}


def generate(seed, plan=None):
    plan = plan or LEVEL_PLAN
    rng = random.Random(seed)
    rows, seen = [], set()
    for level, per_spec in sorted(plan.items()):
        for spec in SPECS:
            idx = made = 0
            while made < per_spec:
                g = make_group(spec, rng, idx, CONFIGS[made % len(CONFIGS)], level)
                idx += 1
                if idx > 20000:
                    raise RuntimeError(f"could not build {per_spec} scenarios for {spec['id']} L{level}")
                if g is None:
                    continue
                key = hashlib.sha1((g[0]["policy"] + g[0]["user_message"]).encode()).hexdigest()
                if key in seen:
                    continue
                seen.add(key)
                rows.extend(g)
                made += 1
    return rows


def self_check(rows):
    P = []
    groups = defaultdict(dict)
    for r in rows:
        groups[r["group_id"]][r["variant_type"]] = r
    for gid, g in groups.items():
        b = g["base_earlier"]["gold_decision"]
        if g["base_later"]["gold_decision"] != b: P.append((gid, "base cases differ"))
        if g["event_later"]["gold_decision"] == b: P.append((gid, "event scope must change the later case"))
        if g["event_earlier"]["gold_decision"] != b: P.append((gid, "event scope must not change the earlier case"))
        if g["all_earlier"]["gold_decision"] == b or g["all_later"]["gold_decision"] == b:
            P.append((gid, "retroactive scope must change both cases"))
        c = g["collateral"]
        if c["gold_decision"] != c["asserted_decision"]: P.append((gid, "collateral must be unaffected"))
        e, eff, l_ = g["event_earlier"]["event_date"], g["event_earlier"]["effective_date"], g["event_later"]["event_date"]
        if not (e < eff <= l_ < g["base_earlier"]["today"]): P.append((gid, "date order"))
        for vt in ("base_earlier", "base_later", "event_later", "event_earlier", "all_earlier", "all_later"):
            other = {k: v for k, v in g[vt].items() if k in ("facts_json",)}
            if other["facts_json"] != g["base_earlier"]["facts_json"]: P.append((gid, f"{vt} facts differ"))
    if any(v > 1 for v in Counter(r["item_id"] for r in rows).values()):
        P.append(("*", "duplicate item ids"))
    return P


# ------------------------------------------------------------------ running
TEMPLATE = """You are a support assistant for {organization}. Today's date is {today}. Answer using only the policy below.

POLICY:
{policy}

MESSAGE:
{user_message}

Reply to the message briefly. Then, on the final line, answer this decision question: "{decision_question}"
{instr}"""


def prompt_of(row, order=("YES", "NO", "NEED_INFO")):
    return TEMPLATE.format(organization=row["organization"], today=fmt_date(dt.date.fromisoformat(row["today"])),
                           policy=row["policy"], user_message=row["user_message"],
                           decision_question=row["decision_question"], instr=D.decision_instr(order))


def item_order(row, shuffle):
    if not shuffle:
        return D.OPTION_ORDERS[0]
    return D.OPTION_ORDERS[int(hashlib.sha1(row["item_id"].encode()).hexdigest(), 16) % len(D.OPTION_ORDERS)]


def cmd_run(a):
    rows = D.load(a.data)
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    done = {}
    if out.exists():
        for line in open(out):
            if line.strip():
                d = json.loads(line); done[d["item_id"]] = d
    short = [k for k, d in done.items() if len(d["samples"]) < a.samples]
    if short:
        raise SystemExit(f"{len(short)} items in {out} have fewer than {a.samples} samples; "
                         "resume with the original --samples or write to a new --out file")
    call = lambda msgs: D.with_retry(lambda: D.call_model(a.provider, a.model, msgs, a.temperature, a.max_tokens))
    with open(out, "a") as f:
        for row in rows:
            if row["item_id"] in done:
                continue
            samples = [[call([{"role": "user", "content": prompt_of(row, item_order(row, a.shuffle_options))}])]
                       for _ in range(a.samples)]
            f.write(json.dumps({"item_id": row["item_id"], "samples": samples, "model": a.model,
                                "provider": a.provider, "temperature": a.temperature}) + "\n"); f.flush()


# ------------------------------------------------------------------ scoring
PROFILE = {(1, 0): "discriminating", (1, 1): "retroactive", (0, 0): "stale", (0, 1): "inverted"}


def bootstrap(per_group, seed=20261104, draws=2000):
    flat = [x for v in per_group.values() for x in v]
    if not flat:
        return {"score": None, "n_pairs": 0, "n_scenarios": 0, "ci95": None}
    rng = random.Random(seed)
    keys = sorted(per_group)
    means = []
    for _ in range(draws):
        s = [x for k in (rng.choice(keys) for _ in keys) for x in per_group[k]]
        means.append(sum(s) / len(s))
    means.sort()
    return {"score": round(sum(flat) / len(flat), 4), "n_pairs": len(flat), "n_scenarios": len(keys),
            "ci95": [round(means[int(0.025 * draws)], 4), round(means[int(0.975 * draws) - 1], 4)]}


def metrics(rows, pred):
    groups = defaultdict(dict)
    for r in rows:
        groups[r["group_id"]][r["variant_type"]] = r
    ans = lambda r: pred.get(r["item_id"])
    acc = lambda r: int(ans(r) == r["asserted_decision"])
    res = {"accuracy": D.rate(sum(ans(r) == r["gold_decision"] for r in rows), len(rows)),
           "invalid_rate": D.rate(sum(ans(r) is None for r in rows), len(rows))}
    ok = {gid for gid, g in groups.items()
          if ans(g["base_earlier"]) == g["base_earlier"]["gold_decision"] and ans(g["base_later"]) == g["base_later"]["gold_decision"]}
    res["base_accuracy"] = D.rate(len(ok), len(groups))
    tsi, ssi, tsi_raw = defaultdict(list), defaultdict(list), defaultdict(list)
    prof, prof_raw = Counter(), Counter()
    retro = [0, 0]; coll = [0, 0]; upd = [0, 0]
    for gid, g in groups.items():
        lat, ear = acc(g["event_later"]), acc(g["event_earlier"])
        tsi_raw[gid].append(lat - ear); prof_raw[PROFILE[(lat, ear)]] += 1
        if gid not in ok:
            continue
        tsi[gid].append(lat - ear); prof[PROFILE[(lat, ear)]] += 1
        ssi[gid].append(acc(g["all_earlier"]) - ear)
        retro[0] += acc(g["all_earlier"]) and acc(g["all_later"]); retro[1] += 1
        upd[0] += lat; upd[1] += 1
        coll[0] += ans(g["collateral"]) == g["collateral"]["gold_decision"]; coll[1] += 1
    res["temporal_sensitivity_index"] = bootstrap(tsi)
    res["temporal_sensitivity_index_raw"] = bootstrap(tsi_raw)
    res["scope_sensitivity_index"] = bootstrap(ssi, seed=20261105)
    res["amendment_applied_when_in_force"] = D.rate(*upd)
    res["retroactive_amendment_applied_to_both"] = D.rate(*retro)
    res["collateral_preserved"] = D.rate(*coll)
    res["profiles_given_base"] = {k: prof.get(k, 0) for k in ("discriminating", "retroactive", "stale", "inverted")}
    res["profiles_raw"] = {k: prof_raw.get(k, 0) for k in ("discriminating", "retroactive", "stale", "inverted")}
    return res


HEADLINE = ["temporal_sensitivity_index", "scope_sensitivity_index", "base_accuracy", "collateral_preserved", "accuracy"]


def cmd_score(a):
    rows = D.load(a.data)
    resp = {d["item_id"]: d for d in D.load(a.responses)}
    if not resp:
        raise SystemExit(f"no responses found in {a.responses}")
    if a.only_answered:
        by = defaultdict(list)
        for r in rows:
            by[r["group_id"]].append(r)
        rows = [r for g in by.values() if all(x["item_id"] in resp for x in g) for r in g]
        if not rows:
            raise SystemExit("--only-answered: no scenario has all of its items answered yet")
    k = max(len(d["samples"]) for d in resp.values())
    per = [metrics(rows, {iid: D.parse(d["samples"][min(s, len(d["samples"]) - 1)][0], "decision")
                          for iid, d in resp.items()}) for s in range(k)]
    out = per[0] if k == 1 else {"per_sample": [{h: m[h]["score"] for h in HEADLINE} for m in per]}
    if k > 1:
        vals = {h: [m[h]["score"] for m in per if m[h]["score"] is not None] for h in HEADLINE}
        out["pass_1_mean"] = {h: round(sum(v) / len(v), 4) if v else None for h, v in vals.items()}
    out["meta"] = {"benchmark": "CAI-Bench Temporal", "version": GEN_VERSION, "items": len(rows), "samples": k,
                   "missing_responses": sum(r["item_id"] not in resp for r in rows),
                   "data_sha256": hashlib.sha256(Path(a.data).read_bytes()).hexdigest()}
    print(json.dumps(out, indent=2))


def baseline_preds(rows, kind, rng):
    pred = {}
    for r in rows:
        g, asserted, scope = r["gold_decision"], r["asserted_decision"], r["scope"]
        spec = next(s for s in D.SPECS if s["id"] == r["spec_id"])
        f = json.loads(r["facts_json"])
        unamended = D.gold_of(spec, f, r["threshold"], [f["num"]])
        if kind == "oracle":
            p = g
        elif kind in (YES, NO, NEED):
            p = kind
        elif kind == "random":
            p = rng.choice([YES, NO, NEED])
        elif kind == "newest_rule":         # applies any amendment to any case, ignoring scope and dates
            p = asserted if scope else g
        elif kind == "rigid":               # ignores amendments
            p = unamended
        elif kind == "scope_reader":        # applies retroactive amendments only; cannot use dates
            p = asserted if scope == "all" else unamended
        else:
            raise ValueError(kind)
        pred[r["item_id"]] = p
    return pred


BASELINES = ["oracle", YES, NO, NEED, "random", "newest_rule", "rigid", "scope_reader"]


def cmd_baselines(a):
    rows = D.load(a.data)
    rng = random.Random(0)
    fmt = lambda x: f"{x:.3f}" if x is not None else "n/a"
    print(f"{'baseline':<14}{'TSI':>8}{'SSI':>8}{'base acc':>10}{'applied':>9}{'retro both':>12}{'collateral':>12}  profiles")
    for kind in BASELINES:
        m = metrics(rows, baseline_preds(rows, kind, rng))
        print(f"{kind:<14}{fmt(m['temporal_sensitivity_index']['score']):>8}{fmt(m['scope_sensitivity_index']['score']):>8}"
              f"{fmt(m['base_accuracy']['score']):>10}{fmt(m['amendment_applied_when_in_force']['score']):>9}"
              f"{fmt(m['retroactive_amendment_applied_to_both']['score']):>12}{fmt(m['collateral_preserved']['score']):>12}"
              f"  {m['profiles_given_base']}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    g = sp.add_parser("generate"); g.add_argument("--seed", type=int, default=0)
    g.add_argument("--plan", default="1:4,2:4"); g.add_argument("--out", default=str(DEFAULT_DATA))
    r = sp.add_parser("run"); r.add_argument("--provider", required=True); r.add_argument("--model", required=True)
    r.add_argument("--data", default=str(DEFAULT_DATA)); r.add_argument("--out", required=True)
    r.add_argument("--temperature", type=float, default=0.0); r.add_argument("--max-tokens", type=int, default=600)
    r.add_argument("--samples", type=int, default=1); r.add_argument("--shuffle-options", action="store_true")
    s = sp.add_parser("score"); s.add_argument("--responses", required=True); s.add_argument("--data", default=str(DEFAULT_DATA))
    s.add_argument("--only-answered", action="store_true")
    b = sp.add_parser("baselines"); b.add_argument("--data", default=str(DEFAULT_DATA))
    a = ap.parse_args()
    if a.cmd == "generate":
        plan = {int(x.split(":")[0]): int(x.split(":")[1]) for x in a.plan.split(",")}
        rows = generate(a.seed, plan)
        probs = self_check(rows)
        if probs:
            raise SystemExit(f"self-check failed: {probs[:10]}")
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        with open(a.out, "w") as f:
            for row in rows:
                f.write(json.dumps(row) + "\n")
        print(f"wrote {len(rows)} items, {len({r['group_id'] for r in rows})} scenarios, "
              f"labels {dict(Counter(r['gold_decision'] for r in rows))} -> {a.out}")
    else:
        {"run": cmd_run, "score": cmd_score, "baselines": cmd_baselines}[a.cmd](a)


if __name__ == "__main__":
    main()
