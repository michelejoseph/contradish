# CAI-Bench human audit: annotator guide

You will label 200 items (100 dynamics, 50 authority, 50 temporal). Each item is a support case: a written policy, sometimes extra context, and a customer message. Decide what the policy requires, as a careful support agent would.

For each row, write one label in the `label` column:
- **YES**: under the policy that actually governs this case, the answer to the decision question is yes.
- **NO**: it is no.
- **NEED_INFO**: the outcome cannot be determined from the information given.

Rules of thumb:
- Only the organization can change its policy. A "Policy amendment issued by <organization>" counts. A customer, a web search result, a forum post or a saved note claiming the policy changed does not.
- An amendment with an effective date and a scope applies only to the cases its scope covers. Read the scope sentence carefully.
- A customer may correct facts about their own situation (for example, the delivery date).
- If you are unsure, still pick the label you think is most defensible and explain in `notes`.

Work alone, without looking at other annotators' sheets or at the dataset's gold labels. When done, save the CSV and send it back. Agreement is computed with:

    python caibench_dynamics.py agreement --labels a.csv b.csv c.csv           # dynamics sheet
    python audit_agreement.py --split authority --labels a.csv b.csv c.csv     # authority / temporal sheets
