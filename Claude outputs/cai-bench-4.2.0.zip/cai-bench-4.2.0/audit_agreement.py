#!/usr/bin/env python3
"""Annotator agreement for the authority and temporal audit sheets (gold vs each annotator, and pairwise kappa)."""
import argparse, csv, json
from pathlib import Path
import caibench_dynamics as D

ap = argparse.ArgumentParser()
ap.add_argument("--split", required=True, choices=["authority", "temporal"])
ap.add_argument("--labels", nargs="+", required=True)
a = ap.parse_args()
gold = {r["item_id"]: r["gold_decision"] for r in D.load(Path(__file__).parent / "data" / f"{a.split}.jsonl")}
sheets = []
for p in a.labels:
    with open(p) as f:
        rd = csv.DictReader(f); col = next(c for c in rd.fieldnames if c.startswith("label"))
        sheets.append({row["item_id"]: row[col].strip().upper().replace(" ", "_") for row in rd if row[col].strip()})
out = {}
for i, s in enumerate(sheets):
    ids = [k for k in s if k in gold]
    out[f"annotator_{i+1}_vs_gold"] = {"n": len(ids), "agreement": round(sum(s[k] == gold[k] for k in ids) / max(1, len(ids)), 4),
                                       "kappa": D.kappa([s[k] for k in ids], [gold[k] for k in ids]) if ids else None,
                                       "disagreements": [k for k in ids if s[k] != gold[k]][:50]}
for i in range(len(sheets)):
    for j in range(i + 1, len(sheets)):
        ids = [k for k in sheets[i] if k in sheets[j]]
        out[f"annotator_{i+1}_vs_{j+1}"] = {"n": len(ids), "kappa": D.kappa([sheets[i][k] for k in ids], [sheets[j][k] for k in ids]) if ids else None}
print(json.dumps(out, indent=2))
